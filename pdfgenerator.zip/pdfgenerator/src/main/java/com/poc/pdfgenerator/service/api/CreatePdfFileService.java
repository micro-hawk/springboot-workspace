package com.poc.pdfgenerator.service.api;

public interface CreatePdfFileService {
    void createPdf();
}
