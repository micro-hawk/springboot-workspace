package com.poc.pdfgenerator.repository;

import com.poc.pdfgenerator.model.entity.City;
import org.springframework.data.repository.CrudRepository;

public interface CityRepository extends CrudRepository<City, Long> {

}
