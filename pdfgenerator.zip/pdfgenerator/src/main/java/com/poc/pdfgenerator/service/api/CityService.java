package com.poc.pdfgenerator.service.api;

import com.poc.pdfgenerator.model.dto.CityDto;
import java.util.List;

public interface CityService {

    List<CityDto> getAllCities();
}
